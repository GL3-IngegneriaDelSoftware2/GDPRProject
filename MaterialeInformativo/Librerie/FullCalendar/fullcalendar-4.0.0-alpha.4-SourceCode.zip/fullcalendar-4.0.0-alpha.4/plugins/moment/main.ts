import * as moment from 'moment'
import * as fc from 'fullcalendar'


export function toMoment(date: Date, calendar: fc.Calendar): moment.Moment {

  if (!(calendar instanceof fc.Calendar)) {
    throw new Error('must supply a Calendar instance')
  }

  return convertToMoment(
    date,
    calendar.dateEnv.timeZone,
    null,
    calendar.dateEnv.locale.codes[0]
  )
}

export function toDuration(fcDuration: fc.Duration): moment.Duration {
  return moment.duration(fcDuration) // momment accepts all the props that fc.Duration already has!
}

// for browser globals. TODO: better solution
(fc as any).Moment = {
  toMoment,
  toDuration
}


fc.registerCmdFormatter('moment', function(cmdStr: string, arg: fc.VerboseFormattingArg) {
  let cmd = parseCmdStr(cmdStr)

  if (arg.end) {
    let startMom = convertToMoment(
      arg.start.array,
      arg.timeZone,
      arg.start.timeZoneOffset,
      arg.localeCodes[0]
    )
    let endMom = convertToMoment(
      arg.end.array,
      arg.timeZone,
      arg.end.timeZoneOffset,
      arg.localeCodes[0]
    )
    return formatRange(
      cmd,
      createMomentFormatFunc(startMom),
      createMomentFormatFunc(endMom),
      arg.separator
    )
  }

  return convertToMoment(
    arg.date.array,
    arg.timeZone,
    arg.date.timeZoneOffset,
    arg.localeCodes[0]
  ).format(cmd.whole) // TODO: test for this
})
fc.globalDefaults.cmdFormatter = 'moment'

function createMomentFormatFunc(mom: moment.Moment) {
  return function(cmdStr) {
    return cmdStr ? mom.format(cmdStr) : '' // because calling with blank string results in ISO8601 :(
  }
}

function convertToMoment(input: any, timeZone: string, timeZoneOffset: number | null, locale: string): moment.Moment {
  let mom: moment.Moment

  if (timeZone === 'local') {
    mom = moment(input)

  } else if (timeZone === 'UTC') {
    mom = moment.utc(input)

  } else if ((moment as any).tz) {
    mom = (moment as any).tz(input, timeZone)

  } else {
    mom = moment.utc(input)

    if (timeZoneOffset != null) {
      mom.utcOffset(timeZoneOffset)
    }
  }

  mom.locale(locale)

  return mom
}


/* Range Formatting (duplicate code as other date plugins)
----------------------------------------------------------------------------------------------------*/

interface CmdParts {
  head: string | null
  middle: CmdParts | null
  tail: string | null
  whole: string
}

function parseCmdStr(cmdStr: string): CmdParts {
  let parts = cmdStr.match(/^(.*?)\{(.*)\}(.*)$/) // TODO: lookbehinds for escape characters

  if (parts) {
    let middle = parseCmdStr(parts[2])

    return {
      head: parts[1],
      middle,
      tail: parts[3],
      whole: parts[1] + middle.whole + parts[3]
    }
  } else {
    return {
      head: null,
      middle: null,
      tail: null,
      whole: cmdStr
    }
  }
}

function formatRange(cmd: CmdParts, formatStart: (cmdStr: string) => string, formatEnd: (cmdStr: string) => string, separator: string): string {
  if (cmd.middle) {
    let startHead = formatStart(cmd.head)
    let startMiddle = formatRange(cmd.middle, formatStart, formatEnd, separator)
    let startTail = formatStart(cmd.tail)

    let endHead = formatEnd(cmd.head)
    let endMiddle = formatRange(cmd.middle, formatStart, formatEnd, separator)
    let endTail = formatEnd(cmd.tail)

    if (startHead === endHead && startTail === endTail) {
      return startHead +
        (startMiddle === endMiddle ? startMiddle : startMiddle + separator + endMiddle) +
        startTail
    }
  }

  return formatStart(cmd.whole) + separator + formatEnd(cmd.whole)
}
