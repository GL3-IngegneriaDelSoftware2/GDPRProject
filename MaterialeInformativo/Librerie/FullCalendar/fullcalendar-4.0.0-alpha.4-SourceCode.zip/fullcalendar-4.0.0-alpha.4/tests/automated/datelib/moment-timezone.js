import { testTimeZoneImpl } from './timeZoneImpl'

describe('moment-timezone', function() {
  testTimeZoneImpl('moment-timezone')
})
